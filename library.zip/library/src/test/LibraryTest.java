package test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import main.Book;
import main.Library;

public class LibraryTest {

	private Library library;

	// This method is executed before each test to set up the library instance
	@BeforeEach
	public void setUp() {
		library = new Library();
	}

	// Test to verify adding a new book to the library
	@Test
	public void testAddBook() {
		Book newBook = new Book("1984", "George Orwell", "9780451524935", "Dystopian Fiction", "1949", "General", true);

		String result = library.addBook(newBook);
		assertEquals("Book added successfully", result);
	}

	// Test to verify that adding a book with an existing ISBN is not allowed
	@Test
	public void testAddExistingBook() {
		Book newBook = new Book("1984", "George Orwell", "9780451524935", "Dystopian Fiction", "1949", "General", true);
		library.addBook(newBook);

		Book existingBook = new Book("The Great Gatsby", "F. Scott Fitzgerald", "9780451524935", "Classic Fiction",
				"1925", "General", true);
		String result = library.addBook(existingBook);
		assertEquals("Book already exist with ISBN : 9780451524935", result);
	}

	// Test to verify removing a book from the library using its ISBN
	@Test
	public void testRemoveBook() {
		Book book = new Book("The Hobbit", "J.R.R. Tolkien", "9780547928227", "Fantasy", "1937", "Theature", false);
		library.addBook(book);
		boolean result = library.removeBook("9780547928227");
		assertTrue(result);
	}

	// Test to verify that attempting to remove a book with a non-matching ISBN
	// returns false
	@Test
	public void testRemoveBookIsbnNotMatching() {
		boolean result = library.removeBook("9780547928290");
		assertFalse(result);
	}

	// Test to verify finding a book by its title
	@Test
	public void testFindBookByTitle() {
		Book book = new Book("Harry Potter and the Philosopher's Stone", "J.K. Rowling", "9781408855652", "Fantasy",
				"1997", "theature", true);
		library.addBook(book);
		List<Book> books = library.findBookByTitle("Harry Potter");
		assertEquals(1, books.size());
	}

	// Test to verify that searching for a non-existent title returns an empty list
	@Test
	public void testFindBookByTitleNoMatch() {
		Book book = new Book("Harry Potter and the Philosopher's Stone", "J.K. Rowling", "9781408855652", "Fantasy",
				"1997", "Fantasy", true);
		library.addBook(book);
		List<Book> books = library.findBookByTitle("Hello");
		assertEquals(0, books.size());
	}

	// Test to verify finding books by their author
	@Test
	public void testFindBookByAuthor() {
		Book book1 = new Book("The Hobbit", "J.R.R. Tolkien", "9780547928227", "Fantasy", "1937", "Fantasy", false);
		Book book2 = new Book("Harry Potter and the Philosopher's Stone", "J.K. Rowling", "9781408855652", "Fantasy",
				"1997", "Fantasy", true);
		library.addBook(book1);
		library.addBook(book2);
		List<Book> books = library.findBookByAuthor("J.");
		assertEquals(2, books.size());
	}

	// Test to verify that searching for a non-existent author returns an empty list
	@Test
	public void testFindBookByAuthorNoMatch() {
		Book book = new Book("The Hobbit", "J.R.R. Tolkien", "9780547928227", "Fantasy", "1937", "Fantasy", false);
		library.addBook(book);
		List<Book> books = library.findBookByAuthor("test");
		assertEquals(0, books.size());
	}

	// Test to verify listing all available books
	@Test
	public void testListAvailableBooks() {
		Book book1 = new Book("The Hobbit", "J.R.R. Tolkien", "9780547928227", "Fantasy", "1937", "Fantasy", false);
		Book book2 = new Book("Harry Potter and the Philosopher's Stone", "J.K. Rowling", "9781408855652", "Fantasy",
				"1997", "Fantasy", true);
		Book book3 = new Book("1984", "George Orwell", "9780451524935", "Dystopian Fiction", "1949", "Fiction", true);
		library.addBook(book1);
		library.addBook(book2);
		library.addBook(book3);
		List<Book> books = library.listAvailableBooks();
		assertEquals(2, books.size());
	}

	// Test to verify listing all books in the library
	@Test
	public void testListAllBooks() {
		Book book1 = new Book("The Hobbit", "J.R.R. Tolkien", "9780547928227", "Fantasy", "1937", "Fantasy", false);
		Book book2 = new Book("Harry Potter and the Philosopher's Stone", "J.K. Rowling", "9781408855652", "Fantasy",
				"1997", "Fantasy", true);
		Book book3 = new Book("1984", "George Orwell", "9780451524935", "Dystopian Fiction", "1949", "Fiction", true);
		library.addBook(book1);
		library.addBook(book2);
		library.addBook(book3);
		List<Book> books = library.listAllBooks();
		assertEquals(3, books.size());
	}
}
