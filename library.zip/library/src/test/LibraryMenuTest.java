package test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.List;
import java.util.Scanner;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import main.Book;
import main.Library;
import main.LibraryMenu;

public class LibraryMenuTest {

	private LibraryMenu menu;
	private Library library;
	private ByteArrayOutputStream outContent;

	// Set up method to initialize Library and redirect System.out to outContent
	@BeforeEach
	public void setUp() {
		library = new Library();
		outContent = new ByteArrayOutputStream();
		System.setOut(new PrintStream(outContent));
	}

	// Helper method to run tests with a specific input string
	private void runTestWithInput(String input) {
		Scanner scanner = new Scanner(input);
		menu = new LibraryMenu(library, scanner);
	}

	// Test to verify the addition of a new book
	@Test
	public void testAddBook() {
		String input = "Advanced C++\nPawan Kumar\n1234567890\nEducation\n2024\nCS\n";
		runTestWithInput(input);
		menu.addBook();

		String output = outContent.toString();
		assertTrue(output.contains("Book added successfully"));
	}

	// Test to verify the handling of adding an existing book
	@Test
	public void testAddExistingBook() {
		Book book = new Book("Software Engineering", "R.D. sharma", "9780547928227", "CS", "1937", "IT", false);
		library.addBook(book);
		String input = "Advanced C++\nPawan Kumar\n9780547928227\nEducation\n2024\nCS\n";
		runTestWithInput(input);

		menu.addBook();
		String output = outContent.toString();
		assertTrue(output.contains("Book already exist with ISBN : "));
	}

	// Test to verify the removal of a book
	@Test
	public void testRemoveBook() {
		Book book = new Book("Test Title", "Test Author", "1234567890", "Fiction", "2024", "CS", true);
		library.addBook(book);

		String input = "1234567890\n";
		runTestWithInput(input);

		menu.removeBook();

		String output = outContent.toString();
		assertTrue(output.contains("Book removed"));
	}

	// Test to verify handling the removal of a non-existent book
	@Test
	public void testRemoveBookNoMatch() {
		Book book = new Book("Test Title", "Test Author", "1234567890", "Fiction", "2024", "CS", true);
		library.addBook(book);

		String input = "1234567899\n";
		runTestWithInput(input);

		menu.removeBook();
		String output = outContent.toString();
		assertTrue(output.contains("Book doesn't exist with ISBN : "));
	}

	// Test to verify finding a book by its title
	@Test
	public void testFindBookByTitle() {
		Book book = new Book("Test Title", "Test Author", "1234567890", "Fiction", "2024", "CS", true);
		library.addBook(book);

		String input = "Test Title\n";
		runTestWithInput(input);

		menu.findBookByTitle();

		List<Book> books = library.findBookByTitle("Test Title");
		assertEquals(1, books.size());
	}

	// Test to verify handling no matches for a title search
	@Test
	public void testFindBookByTitleNoMatch() {
		Book book = new Book("Test Title", "Test Author", "1234567890", "Fiction", "2024", "CS", true);
		library.addBook(book);

		String input = "Advanced\n";
		runTestWithInput(input);

		menu.findBookByTitle();
		String output = outContent.toString();
		assertTrue(output.contains("No match found"));

	}

	// Test to verify finding a book by its author
	@Test
	public void testFindBookByAuthor() {
		Book book = new Book("Test Title", "Test Author", "1234567890", "Fiction", "2024", "CS", true);
		library.addBook(book);

		String input = "Test Author\n";
		runTestWithInput(input);

		menu.findBookByAuthor();

		List<Book> books = library.findBookByAuthor("Test Author");
		assertEquals(1, books.size());
	}

	// Test to verify handling no matches for an author search
	@Test
	public void testFindBookByAuthorNoMatch() {
		Book book = new Book("Test Title", "Test Author", "1234567890", "Fiction", "2024", "CS", true);
		library.addBook(book);

		String input = "R.D.\n";
		runTestWithInput(input);

		menu.findBookByAuthor();
		String output = outContent.toString();
		assertTrue(output.contains("No match found"));

	}

	// Test to verify listing all books
	@Test
	public void testListAllBooks() {
		Book book1 = new Book("Title1", "Author1", "ISBN1", "Fiction", "2024", "CS", true);
		Book book2 = new Book("Title2", "Author2", "ISBN2", "Non-Fiction", "2023", "Math", true);
		library.addBook(book1);
		library.addBook(book2);
		runTestWithInput("");

		menu.listAllBooks();
		String output = outContent.toString();
		assertTrue(output.contains("Book ["));
	}

	// Test to verify listing all books when the list is empty
	@Test
	public void testListAllBooksWithEmptyList() {
		runTestWithInput("");

		menu.listAllBooks();

		String output = outContent.toString();
		assertTrue(output.contains("No book exist"));
	}

	// Test to verify listing all available books
	@Test
	public void testListAvailableBooks() {
		Book book1 = new Book("Title1", "Author1", "ISBN1", "Fiction", "2024", "CS", true);
		Book book2 = new Book("Title2", "Author2", "ISBN2", "Non-Fiction", "2023", "Math", false);
		library.addBook(book1);
		library.addBook(book2);
		runTestWithInput("");

		menu.listAvailableBooks();
		String output = outContent.toString();
		assertTrue(output.contains("Book ["));

	}

	// Test to verify listing available books when none are available
	@Test
	public void testListAvailableBooksWithEmptyList() {
		Book book2 = new Book("Title2", "Author2", "ISBN2", "Non-Fiction", "2023", "Math", false);
		library.addBook(book2);

		runTestWithInput("");

		menu.listAvailableBooks();

		String output = outContent.toString();
		assertTrue(output.contains("No book available"));
	}

	// Test to verify the display of the menu and its options
	@Test
	public void testDisplayMenu() {
		String input = "1\nAdvanced C++\nPawan Kumar\n1234567890\nEducation\n2024\nCS\n" + // Add a book
				"3\nAdvanced C++\n" + // Find book by title
				"4\nPawan Kumar\n" + // Find book by author
				"5\n" + // List all books
				"2\n1234567890\n" + // Remove book
				"6\n" + // List available books
				"8\n" + // Invalid choice
				"7\n"; // Exit

		System.setIn(new ByteArrayInputStream(input.getBytes()));
		String[] args = {};
		LibraryMenu.main(args);

		String output = outContent.toString();

		assertTrue(output.contains("Welcome to Library Management System !"));
		assertTrue(output.contains("Menu :"));
		assertTrue(output.contains("1. Add Book"));
		assertTrue(output.contains("2. Remove Book"));
		assertTrue(output.contains("3. Find Book by Title"));
		assertTrue(output.contains("4. Find Book by Author"));
		assertTrue(output.contains("5. List All Books"));
		assertTrue(output.contains("6. List Available books"));
		assertTrue(output.contains("7. exit"));
		assertTrue(output.contains("Thanks ! Application is closed"));
	}

	// Test to verify handling of empty inputs when adding a book
	@Test
	public void testEmtptyInputs() {
		String input = "\nAdvanced C++\n\nPawan Kumar\n\n\n1234567890\nEducation\n2024\nCS\n";

		runTestWithInput(input);
		menu.addBook();

		String output = outContent.toString();
		assertTrue(output.contains("Title cannot be empty"));
		assertTrue(output.contains("Author cannot be empty"));
		assertTrue(output.contains("ISBN cannot be empty"));
	}
}
