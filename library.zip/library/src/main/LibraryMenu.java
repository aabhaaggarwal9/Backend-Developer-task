package main;

import java.util.List;
import java.util.Scanner;

public class LibraryMenu {

	private Library library;
	private Scanner scanner;

	// Constructor to initialize the library and scanner objects
	public LibraryMenu(Library library, Scanner scanner) {
		this.library = library;
		this.scanner = scanner;
	}

	// Method to display the main menu
	public void displayMenu() {
		int choice;
		System.out.println("Welcome to Library Management System !");
		do {
			System.out.println("Menu :");
			System.out.println("1. Add Book");
			System.out.println("2. Remove Book");
			System.out.println("3. Find Book by Title");
			System.out.println("4. Find Book by Author");
			System.out.println("5. List All Books");
			System.out.println("6. List Available books");
			System.out.println("7. exit");
			System.out.println("Enter your choice");

			// Taking user input
			choice = scanner.nextInt();

			// Consume newline left-over
			scanner.nextLine();

			// Handling user choices
			switch (choice) {
			case 1:
				addBook();
				break;

			case 2:
				removeBook();
				break;
			case 3:
				findBookByTitle();
				break;
			case 4:
				findBookByAuthor();
				break;
			case 5:
				listAllBooks();
				break;
			case 6:
				listAvailableBooks();
				break;
			case 7:
				System.out.println("Existing Library management system");
				break;
			default:
				System.out.println("Enter a valid choice");
			}
		} while (choice != 7);

		System.out.println("Thanks ! Application is closed");
		scanner.close();
	}

	// Method to add a new book to the library
	public void addBook() {
		System.out.println("Enter book details: ");
		String title = null;
		String author = null;
		String isbn = null;
		Boolean check = true;

		// Loop to ensure non-empty values for title, author, and ISBN
		do {
			if (title == null || title.equals("")) {
				System.out.println("Title : ");
				title = scanner.nextLine().trim();
				if (title.equals("")) {
					System.out.println("Title cannot be empty");
					continue;
				}
			}
			if (author == null || author.equals("")) {
				System.out.println("Author : ");
				author = scanner.nextLine().trim();
				if (author.equals("")) {
					System.out.println("Author cannot be empty");
					continue;
				}
			}
			if (isbn == null || isbn.equals("")) {
				System.out.println("ISBN : ");
				isbn = scanner.nextLine().trim();
				if (isbn.equals("")) {
					System.out.println("ISBN cannot be empty");
					continue;
				}
			}
			check = false;
		} while (check);

		// Additional book details
		System.out.println("Genre : ");
		String genre = scanner.nextLine().trim();
		System.out.println("Publication year : ");
		String pubYear = scanner.nextLine().trim();
		System.out.println("Department : ");
		String department = scanner.nextLine().trim();

		// Creating a new book object and adding it to the library
		Book book = new Book(title, author, isbn, genre, pubYear, department, true);
		String response = library.addBook(book);
		System.out.println(response);
	}

	// Method to remove a book from the library using its ISBN
	public void removeBook() {
		System.out.println("Enter ISBN number of the book you want to remove");
		String isbn = scanner.nextLine().trim();
		boolean response = library.removeBook(isbn);

		if (!response) {
			System.out.println("Book doesn't exist with ISBN : " + isbn);
		} else {
			System.out.println("Book removed");
		}

	}

	// Method to find books by their title
	public void findBookByTitle() {
		System.out.println("Enter title to search : ");
		String title = scanner.nextLine().trim();
		List<Book> books = library.findBookByTitle(title);
		if (books.isEmpty()) {
			System.out.println("No match found");
		} else {
			books.forEach(book -> System.out.println(book.toString()));
		}

	}

	// Method to find books by their author
	public void findBookByAuthor() {
		System.out.println("Enter author to search : ");
		String author = scanner.nextLine().trim();
		List<Book> books = library.findBookByAuthor(author);
		if (books.isEmpty()) {
			System.out.println("No match found");
		} else {
			books.forEach(book -> System.out.println(book.toString()));
		}

	}

	// Method to list all books in the library
	public void listAllBooks() {
		List<Book> books = library.listAllBooks();
		if (books.isEmpty()) {
			System.out.println("No book exist");
		} else {
			books.forEach(book -> System.out.println(book.toString()));
		}

	}

	// Method to list all available books in the library
	public void listAvailableBooks() {
		List<Book> books = library.listAvailableBooks();
		if (books.isEmpty()) {
			System.out.println("No book available");
		} else {
			books.forEach(book -> System.out.println(book.toString()));
		}

	}

	// Main method to start the application
	public static void main(String[] args) {
		Library library = new Library();
		Scanner scanner = new Scanner(System.in);
		LibraryMenu libraryMenu = new LibraryMenu(library, scanner);
		libraryMenu.displayMenu();
	}

}
