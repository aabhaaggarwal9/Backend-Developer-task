package main;

import java.util.ArrayList;
import java.util.List;

public class Library {
	private List<Book> books;

	// Constructor to initialize the books list
	public Library() {
		this.books = new ArrayList<>();
	}

	// Method to add a new book to the library
	public String addBook(Book book) {
		Boolean isbn = books.stream().anyMatch(existBook -> existBook.getIsbn().equals(book.getIsbn()));
		// Check if a book with the same ISBN already exists
		if (isbn) {
			return "Book already exist with ISBN : " + book.getIsbn();
		}
		books.add(book);
		return "Book added successfully";
	}

	// Method to remove a book from the library using its ISBN
	public Boolean removeBook(String isbn) {

		// Remove the book if it matches the given ISBN
		return books.removeIf(book -> book.getIsbn().equals(isbn));
	}

	// Method to find books by their title
	public List<Book> findBookByTitle(String title) {

		// Filter books that contain the title (case insensitive)
		return books.stream().filter(book -> book.getTitle().toLowerCase().contains(title.toLowerCase())).toList();
	}

	// Method to find books by their author
	public List<Book> findBookByAuthor(String author) {

		// Filter books that contain the author's name (case insensitive)
		return books.stream().filter(book -> book.getAuthor().toLowerCase().contains(author.toLowerCase())).toList();
	}

	// Method to list all books in the library
	public List<Book> listAllBooks() {
		return books;
	}

	// Method to list all available books in the library
	public List<Book> listAvailableBooks() {

		// Filter books that are available
		return books.stream().filter(book -> book.isAvailability()).toList();
	}

}
