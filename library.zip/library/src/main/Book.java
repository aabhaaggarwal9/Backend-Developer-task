package main;

public class Book {

	private String title;
	private String author;
	private String isbn;
	private String genre;
	private String publicationYear;
	private String department;
	private boolean availability;

	// Getter methods
	public String getTitle() {
		return title;
	}

	public String getAuthor() {
		return author;
	}

	public String getIsbn() {
		return isbn;
	}

	public boolean isAvailability() {
		return availability;
	}

	public Book(String title, String author, String isbn, String genre, String publicationYear, String department,
			boolean availability) {
		this.title = title;
		this.author = author;
		this.isbn = isbn;
		this.genre = genre;
		this.publicationYear = publicationYear;
		this.department = department;
		this.availability = availability;
	}

	@Override
	public String toString() {
		return "Book [title=" + title + ", author=" + author + ", isbn=" + isbn + ", genre=" + genre
				+ ", publicationYear=" + publicationYear + ", department=" + department + ", availability="
				+ availability + "]";
	}
}
